/*document.addEventListener("DOMContentLoaded", function () {
    var scrollbar = document.body.clientWidth - window.innerWidth + 'px';
    console.log(scrollbar);
    document.querySelector('[href="#camera"]').addEventListener('click', function () {
        document.body.style.overflow = 'hidden';
        document.querySelector('#camera').style.marginLeft = scrollbar;
    });
    document.querySelector('[href="#close"]').addEventListener('click', function () {
        document.body.style.overflow = 'visible';
        document.querySelector('#camera').style.marginLeft = '0px';
    });
});*/


var width = 320;    // We will scale the photo width to this
var height = 0;     // This will be computed based on the input stream

// |streaming| indicates whether or not we're currently streaming
// video from the camera. Obviously, we start at false.

var streaming = false;

// The various HTML elements we need to configure or control. These
// will be set by the startup() function.

var video = null;
var canvas = null;
var imageBase64;
var tid;

function onCamera() {
    console.log('oncamera');
    video = document.getElementById('video');
    canvas = document.getElementById('canvas');
    console.log('video.videoHeight = ' + video.videoHeight);
    console.log('video.videoWidth = ' + video.videoWidth);
    navigator.mediaDevices.getUserMedia({ audio: false, video: { facingMode: { exact: "environment" } } })
        .then(function (stream) {
            video.srcObject = stream;
            video.play();
        })
        .catch(function (err) {
            console.log("An error occurred: " + err);
        });

    video.addEventListener('canplay', function (ev) {
        if (!streaming) {
            height = video.videoHeight / (video.videoWidth / width);

            // Firefox currently has a bug where the height can't be read from
            // the video, so we will make assumptions if this happens.

            if (isNaN(height)) {
                height = width / (4 / 3);
            }

            video.setAttribute('width', width);
            video.setAttribute('height', height);
            canvas.setAttribute('width', width);
            canvas.setAttribute('height', height);
            streaming = true;
        }
    }, false);

    clearphoto();

    if (streaming) {
        makePhoto();
    }
}

// Fill the photo with an indication that none has been
// captured.

function clearphoto() {
    var context = canvas.getContext('2d');
    context.fillStyle = "#AAA";
    context.fillRect(0, 0, canvas.width, canvas.height);
}

function makePhoto() {
    console.log('makePhoto');
    var context = canvas.getContext('2d');
    if (width && height) {
        canvas.width = width;
        canvas.height = height;
        context.drawImage(video, 0, 0, width, height);

        imageBase64 = canvas.toDataURL('image/jpeg').replace('data:image/jpeg;base64,', '');

        var requestData = {
            data: imageBase64
        };

        // Создание HTTP-запроса
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "/detect", true);
        xhr.setRequestHeader("Content-type", "application/json");

        // Отправка данных на серверный API
        xhr.send(JSON.stringify(requestData));

        // Обработчик события изменения состояния запроса
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var responseJson = JSON.parse(xhr.responseText);
                var message = responseJson.message;
                /*var messageOutput = document.getElementById("message-output");
                messageOutput.innerHTML = "Server message: " + message;*/
                offCamera();
                window.location.href = '#close';
            }
        };

    } else {
        clearphoto();
    }

    tid = setTimeout(makePhoto, 2000);
}

function offCamera() { // to be called when you want to stop the timer
    clearphoto();
    clearTimeout(tid);
}
