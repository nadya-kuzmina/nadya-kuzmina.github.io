const Keyboard = {
    elements: {
        main: null,
        keysContainer: null,
        keys: []
    },

    eventHandlers: {
        oninput: null,
        onclose: null
    },

    value: "",

    init() {
        // Create main elements
        this.elements.main = document.createElement("div");
        this.elements.keysContainer = document.createElement("div");

        // Setup main elements
        //this.elements.main.classList.add("keyboard", "keyboard--hidden");
        this.elements.main.classList.add("keyboard");
        this.elements.keysContainer.classList.add("keyboard__keys");
        this.elements.keysContainer.appendChild(this._createKeys());

        this.elements.keysLetters = this.elements.keysContainer.querySelectorAll(".keyboard__key--letter");

        this.elements.main.appendChild(this.elements.keysContainer);
         document.body.appendChild(this.elements.main);
        //document.querySelector(".main").appendChild(this.elements.main);

        const $number = document.getElementById("regnum");
        const $reg = document.getElementById("region");
        [$number, $reg].forEach(element => {
            element.addEventListener("focus", () => {
                this.open(element.value, element.dataset.digitsOnly, key => {
                    if (key === "backspace")
                        element.value = element.value.substring(0, element.value.length - 1);
                    else if (element.value.length < element.maxLength)
                        element.value += key;
                    search($number.value.toLowerCase(), $reg.value.toLowerCase());
                });
            });
        });
    },

    _createKeys() {
        const fragment = document.createDocumentFragment();
        const keyLayout = [
            "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "backspace",
            /*"done", */"A", "B", "E", "K", "M", "H", "O", "P", "T", "C", "У", "X"
        ];

        const createIconHTML = (icon_name) => {
            return `<i class="material-icons">${icon_name}</i>`;
        };

        keyLayout.forEach(key => {
            const keyElement = document.createElement("button");
            let insertLineBreak = false;

            // Add attributes/classes
            keyElement.setAttribute("type", "button");
            keyElement.classList.add("keyboard__key");

            switch (key) {
                case "backspace":
                    keyElement.classList.add("keyboard__key--wide");
                    keyElement.innerHTML = createIconHTML("backspace");
                    keyElement.addEventListener("click", () => {
                        this._triggerEvent("oninput", key);
                    });
                    insertLineBreak = true;
                    break;

                /*case "done":
                    keyElement.classList.add("keyboard__key--wide", "keyboard__key--dark");
                    keyElement.innerHTML = createIconHTML("check_circle");
                    keyElement.addEventListener("click", () => {
                        this.close();
                        this._triggerEvent("onclose");
                    });
                    break;*/

                default:
                    if (isNaN(key))
                        keyElement.classList.add("keyboard__key--letter");
                    keyElement.textContent = key;
                    keyElement.addEventListener("click", () => {
                        this._triggerEvent("oninput", key);
                    });

                    break;
            }

            fragment.appendChild(keyElement);

            if (insertLineBreak) {
                fragment.appendChild(document.createElement("br"));
            }
        });

        return fragment;
    },

    _triggerEvent(handlerName, key) {
        if (typeof this.eventHandlers[handlerName] == "function") {
            this.eventHandlers[handlerName](key);
        }
    },

    open(initialValue, digitsOnly, oninput, onclose) {
        this.value = initialValue || "";
        this.eventHandlers.oninput = oninput;
        this.eventHandlers.onclose = onclose;
        //this.elements.main.classList.remove("keyboard--hidden");
        this.elements.keysLetters.forEach(key => {
            key.disabled = (digitsOnly !== undefined);
        });
    },

    /*close() {
        this.value = "";
        this.eventHandlers.oninput = oninput;
        this.eventHandlers.onclose = onclose;
        this.elements.main.classList.add("keyboard--hidden");
    },*/
};

window.addEventListener("DOMContentLoaded", function () {
    Keyboard.init();
});