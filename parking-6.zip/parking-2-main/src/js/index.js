var wb;
var rABS = false;
// only a small subset of Cyrillic characters that look like Latin characters 
// are used (12 letters: А, В, Е, К, М, Н, О, Р, С, Т, У, Х)
var payload = ['р140оу11', 'о672еа159', 'о546кк96', 'р315ое750'];
const cyrMap = new Map([
  ['a', 'а'],
  ['b', 'в'],
  ['e', 'е'],
  ['k', 'к'],
  ['m', 'м'],
  ['h', 'н'],
  ['o', 'о'],
  ['p', 'р'],
  ['t', 'т'],
  ['c', 'с'],
  ['y', 'у'],
  ['x', 'х']
]);

function importExcel(obj) {
  if (!obj.files) {
    return;
  }
  const IMPORTFILE_MAXSIZE = 1 * 8024;
  const name = obj.files[0].name;
  var suffix = name.split(".")[1];
  if (suffix !== "xls" && suffix !== "xlsx") {
    alert("Неверный формат импортированного файла");
    return;
  }
  if (obj.files[0].size / 8024 > IMPORTFILE_MAXSIZE) {
    alert("Размер импортируемой таблицы не может превышать 8M");
    return;
  }
  var f = obj.files[0];
  var reader = new FileReader();
  reader.onload = function (e) {
    var data = e.target.result;
    if (rABS) {
      wb = XLSX.read(btoa(fixdata(data)), {
        type: "base64"
      });
    } else {
      wb = XLSX.read(data, {
        type: "binary"
      });
    }

    const jsonSheet = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1 });
    payload.push(...jsonSheet.map(e => {
      return lat2Cyr(e.toString().replace(/\s/g, '').toLowerCase());
    }));

    var requestData = {
      data: btoa(encodeURIComponent(payload.join()))
    };
    /* uncomment this if cyrillic string in json is enough
        var requestData = {
        data: payload.join()
      };
    */

    // to decode cyrillic string 'р140оу11,о672еа159,о546кк96,р315ое750...'
    // it is needed to call decodeURIComponent(atob(dec)) logic on server
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "/load", true);
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.send(JSON.stringify(requestData));
  };
  if (rABS) {
    reader.readAsArrayBuffer(f);
  } else {
    reader.readAsBinaryString(f);
  }
}

function lat2Cyr(word) {
  var characters = word.split('');
  characters.forEach((c, index) => {
    if (cyrMap.has(c))
      characters[index] = cyrMap.get(c);
  })
  return characters.join('');
}

function search(number, region) {
  const match = document.getElementById("matches");
  if (number.length === 0 && region.length === 0) {
    match.innerHTML = '';
    return;
  }
  console.log("search1");
  number = lat2Cyr(number);

  var num, reg;
  const matches = payload.filter((v) => {
    v = v.toLowerCase();
    num = v.substring(0, 6);
    reg = v.substring(6, 9);
    return (num.includes(number) && reg.includes(region));
  });
  console.log("search2");
  var matchesHTML = '';
  if (matches.length > 0) {
    matchesHTML = matches
      .map((match) => `<p>${String(match).toUpperCase()}</p>`)
      .join("");
  } else {
    matchesHTML = `<span class="text" style="font-size: 36px; color: #c00;">Проезд запрещен</span>`;
  }
  console.log("search3 = " + matchesHTML);
  match.innerHTML = matchesHTML;
}

function fixdata(data) {
  var o = "",
    l = 0,
    w = 10240;
  for (; l < data.byteLength / w; ++l)
    o += String.fromCharCode.apply(
      null,
      new Uint8Array(data.slice(l * w, l * w + w))
    );
  o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w)));
  return o;
}

void document.getElementById("upload-file")?.addEventListener("click", function () {
  document.getElementById("file").click();
});

void document.getElementById("file")?.addEventListener("change", function listener() {
  importExcel(this);
  const name = this.files[0].name;
  document.getElementById("file-name").innerText = name;
  window.location.href = '#close';
});
/*
void document.getElementById("clean")?.addEventListener("click", function () {
  document.getElementById("regnum").value = '';
  document.getElementById("region").value = '';
  document.getElementById("matches").innerHTML = '';
});

const $number = document.querySelector("#regnum");
const regex = /[АВЕКМНРОСТУХавекмнорстухABEKMHOPCTYXabekmhoptcyx0-9\/]+/;
$number.addEventListener("keydown", e => {
  if (!regex.test(e.key) &&
    e.keyCode !== 8 &&
    e.keyCode !== 46 &&
    e.keyCode !== 37 &&
    e.keyCode !== 39) {
    e.preventDefault();
  }
});

const $reg = document.querySelector("#region");
$reg.addEventListener("keydown", e => {
  if ((e.keyCode < 48 || e.keyCode > 57) &&
    e.keyCode !== 8 &&
    e.keyCode !== 46 &&
    e.keyCode !== 37 &&
    e.keyCode !== 39) {
    e.preventDefault();
  }
});

$number.addEventListener("input", e => {
  console.log("input event detected 1! coming from this element:", e.target);
  search(e.target.value.toLowerCase(), $reg.value.toLowerCase());
});

$reg.addEventListener("input", e => {
  console.log("input event detected 2! coming from this element:", e.target);
  search($number.value.toLowerCase(), e.target.value.toLowerCase());
});
*/
window.addEventListener("DOMContentLoaded", function () {
  let fileName = document.getElementById("file-name").innerText;
  if (!fileName) {
    window.location.href = '#upload';
  }
});